
MINMAX:
DEPTH = 4, NODES EXPANDED: 5,812,612,128
DEPTH = 3, NODES EXPANDED:    22,015,008
TIME COMPLEXITY: O(∑ from i = 0 to d of (n! * 8^i)/(n-i)!) for d = depth, n = number of moves left
SPACE COMPLEXITY: O(d) for d = depth



MINMAX WITH ALPHA/BETA PRUNING:
DEPTH = 4, NODES EXPANDED: 1,354,686,575
DEPTH = 3, NODES EXPANDED:     6,983,529
TIME COMPLEXITY: O(∑ from i = 0 to d of (n! * 8^i)/(n-i)!) for d = depth, n = number of moves left
SPACE COMPLEXITY: O(d) for d = depth
